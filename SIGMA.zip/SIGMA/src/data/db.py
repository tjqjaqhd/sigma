"""
db.py
DB/메모리 캐시 연동 및 데이터 저장/조회 모듈
"""

def save_data(data):
    """
    데이터 저장 함수
    """
    pass

def load_data(query):
    """
    데이터 조회 함수
    """
    pass 