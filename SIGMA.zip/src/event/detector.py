"""
detector.py
트리거/이벤트 감지 모듈
"""

def detect_event(processed_data):
    """
    이벤트 감지 함수
    """
    pass 