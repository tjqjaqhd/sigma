"""
preprocessor.py
수집된 데이터의 전처리 및 정제 모듈
"""

def clean_data(raw_data):
    """
    데이터 정제 함수
    """
    pass

def normalize_data(cleaned_data):
    """
    데이터 정규화 함수
    """
    pass 