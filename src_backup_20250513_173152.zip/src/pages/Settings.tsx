import React from 'react';
import { Box, Typography } from '@mui/material';

const Settings: React.FC = () => {
  return (
    <Box sx={{ maxWidth: 480, mx: 'auto', mt: 6, p: 2 }}>
      <Typography variant="h4" color="primary" sx={{ mb: 2 }}>테스트 빌드: 2024-05-13</Typography>
    </Box>
  );
};

export default Settings; 